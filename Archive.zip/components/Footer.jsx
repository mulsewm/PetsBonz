import React from 'react';
import Image from 'next/image';
import { GrFacebookOption, GrTwitter, GrLinkedinOption } from 'react-icons/gr';
import logo from '../src/assets/Isolation_Mode.png'

const Footer = () => {
  return (
    <footer>
      <div className='footer'>
        <div className='footer-column'>
          <div className='logo'>
            <Image src={logo} width={100} height={45} alt='logo' />
            <h1>Petopia</h1>
            <p>Tristique nulla aliquet enim tortor at auctor urna nunc. Massa enim nec dui nunc mattis enim ut tellus. Sed ut perspiciatis unde ...</p>
            <h2>(913) 756-3126</h2>
          </div>
        </div>

        <div className='footer-column'>
          <h3>Working Hours</h3>
          <p>Mon - Fri: 7am – 6pm</p>
          <p>Saturday: 9am – 4pm</p>
          <p>Sunday: Closed</p>
        </div>

        <div className='footer-column'>
          <h3>Useful Links</h3>
          <ul>
            <li>Home</li>
            <li>FAQ</li>
            <li>About</li>
            <li>Gallery</li>
            <li>Services</li>
            <li>Delivery</li>
            <li>Email</li>
          </ul>
        </div>

        <div className='footer-column'>
          <h3>Newsletter</h3>
          <p>Be first in the queue! Get our latest news straight to your inbox.</p>
          <form>
            <input type='email' placeholder='Enter your email' />
            <button type='submit'>Subscribe</button>
          </form>
          <div className='icon-container'>
            <div><GrTwitter size={20} /></div>
            <div><GrFacebookOption size={20} /></div>
            <div><GrLinkedinOption size={20} /></div>
          </div>
        </div>
      </div>

      <div className='footer-bottom'>
        <p>NOOT ©  All rights reserved Copyrights 2023</p>
        <p>Code by. <span>Mulusew M</span></p>
      </div>
    </footer>
  );
};

export default Footer;