import React from 'react'
import Image from 'next/image'
// import event1 from '../src/assets/event2.png' 
// import event2 from '../src/assets/event2.png' 
// import event3 from '../src/assets/event3.png' 

const EventsBanner = () => {
  return (
    <section className='event-container' style={{ backgroundColor: '#7C58D3', borderRadius: '10px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <div>
          <h3><i className="fas fa-check"></i> 120+</h3>
          <p>Satisfied Clients</p>
        </div>
        <div>
          <h3><i className="fas fa-clock"></i> 20+</h3>
          <p>Years Experience</p>
        </div>
        <div>
          <h3><i className="fas fa-tags"></i> 70+</h3>
          <p>Brands Available</p>
        </div>
        <div>
          <h3><i className="fas fa-tags"></i> 200+</h3>
          <p>Products for pets</p>
        </div>
      </div>
    </section>
  )
}

export default EventsBanner