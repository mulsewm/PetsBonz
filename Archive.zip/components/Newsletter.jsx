import React from 'react'
import { GrFacebookOption, GrTwitter, GrLinkedinOption } from 'react-icons/gr';

const Newsletter = () => {
  const handleSubmit = (event) => {
    event.preventDefault();
  };

  return (
    <section className='newsletter'>
<div>
<p>OUR CONTACTS</p>
</div>
<div>
  <h3>Contacts</h3>
  <p>Massa enim nec dui nunc mattis enim ut tellus</p>
  
</div>
     <div className='footer'>
        <div className='footer-column'>
            <h3>Phone</h3>
            <p>(913) 756-3126</p>
        </div>

        <div className='footer-column'>
          <h3>Email</h3>
          <p>petopia@example.com</p>
         <p>petopia@email.com</p>
        </div>

        <div className='footer-column'>
          <h3>Adress</h3>
        <p>17 Parkman Place, 2122 United States </p>
        </div>
        <div className='footer-column'>
          <h3>Working Hours</h3>
          <p>Mon - Fri: 7am – 6pm</p>
          <p>Saturday: 9am – 4pm</p>
          <p>Sunday: Closed</p>
        </div>
        
    </div>
  
    </section>
    
  )
}

export default Newsletter