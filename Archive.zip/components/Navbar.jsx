import React, { useState } from 'react'
import Image from 'next/image'
import {CiSearch} from 'react-icons/ci'
import {CgShoppingCart} from 'react-icons/cg'
import logo from '../src/assets/Isolation_Mode.png'
import Link from 'next/link'
import {RiMenu3Line, RiCloseLine } from 'react-icons/ri';
import { useStateContext } from '../context/StateContext';

import { useRouter } from 'next/router';

const Navbar = ({ Searchproducts }) => {
  const router = useRouter();
  const { showCart, setShowCart, totalQty } = useStateContext();
  const [toggleMenu, setToggleMenu] = useState(false);

  return (
    <nav>
      <Link href="/">
        <Image src={logo} width={100} height={45} alt="logo" />
      </Link>
      <ul className="nav-links">
        <Link href="/">
          <li className={router.pathname === '/' ? 'current-page' : ''}>Home</li>
        </Link>
        <Link href="/Home"><li>Services</li></Link>
        <Link href="#"><li>Shop</li></Link>
        <Link href="#"><li>Blog</li></Link>
        <Link href="#"><li>Pages</li></Link>
        <Link href="#">
        <button className="cart-button" onClick={() => setShowCart(false)}>
          <CgShoppingCart size={25} />
          <span className="cart-item-qty">1 Item</span>
        </button>
        </Link>
      </ul>

      <div className="navbar-smallscreen">
        <RiMenu3Line color="black" fontSize={27} onClick={() => setToggleMenu(true)} />
        {toggleMenu && (
          <div className="navbar-smallscreen_overlay">
            <Link href="/">
              <Image className="logo-small" src={logo} width={140} height={25} alt="logo" />
            </Link>
            <RiCloseLine color="black" fontSize={27} className="close_icon" onClick={() => setToggleMenu(false)} />
            <ul className="navbar-smallscreen_links">
              <Link href="/#">
                <button className="cart-small-screen" onClick={() => setShowCart(false)}>
                  <CgShoppingCart size={22} />
                  <span className="cart-item-qty">1 Item</span>
                </button>
              </Link>
              <Link href="#"><li>Services</li></Link>
              <Link href="#"><li>Shop</li></Link>
              <Link href="#"><li>Blogs</li></Link>
              <Link href="#"><li>Pages</li></Link>
            </ul>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;