import React from 'react'
import Image from 'next/image'
import {CgShoppingCart} from 'react-icons/cg'
import headerImg from '../src/assets/dog11.png'
import Link from 'next/link';

const HeroBanner = () => {
  return (
    <header className='header'>
        <div className='header-left-side'>
            <div className='header-content'>
            <p style={{ color: '#9C5BF5' }}>WE CARE FOR YOUR PETS</p>
                <h1>We Help You Care for Animals with Nutrition</h1>
                <p>All offers are subject to availability. Ut tortor pretium viverra suspendisse potenti nullam ac tortor vitae. Consectetur a erat nam at. Potenti nullam ac tortor vitae purus faucibus ornare.</p>
            </div>
            <div className='header-featured'>
            <div className='row'>
        <div className='column' style={{marginRight: '20px'}}>
            <h3>Trust & Safety</h3>
            <p>Velit euismod pellentes.</p>
            <i className='icon'></i>
        </div>
        <div className='column'>
            <i className='icon'></i>
            <h3>Discounts</h3>
            <p>Bibendum ut tristique</p>
        </div>
        </div>
        <div className='row'>
        <div className='column'>
            <i className='icon'>;</i>
            <h3>Support</h3>
            <p>Egestas quis ipsum velit</p>
        </div>
        <div className='column'>
            <i className='icon shield-check'></i>
            <h3>Guarantee</h3>
            <p>Convallis tellus id interdum</p>
        </div>
        </div>
        </div>
    </div>
        <div className='header-right-side'>
            <div className='header-circle'>
                <Image className='header-img' src={headerImg} width={650} height={650} alt='header image' />
            </div>
        </div>
    </header>
  )
}

export default HeroBanner